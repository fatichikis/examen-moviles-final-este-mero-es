package com.example.examenfinal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class OtherActivity extends AppCompatActivity {

    private EditText mEditSaludo;
    private Button mButtonEnviar;
    private Button mButtonMostrar;


    private static final String SEND_MESSAGE = "mensaje";
    private static final String EXTRA_NAME_SHOWN = "extra";

    public static Intent newIntent
            (Context packageContext, String message) {
        Intent a = new Intent(packageContext,
                OtherActivity.class);
        a.putExtra(SEND_MESSAGE, message);
        return a;
    }

    private void sendBackName(String name){
        Intent data=new Intent();

        data.putExtra(EXTRA_NAME_SHOWN,  name);
        setResult(RESULT_OK, data);
    }
    public static String wasNameShown(Intent result) {
        return result.getStringExtra(EXTRA_NAME_SHOWN);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);

        mEditSaludo = (EditText)findViewById(R.id.editTextsaludo);
        mButtonEnviar = (Button)findViewById(R.id.button_enviarnotificaicon);
        mButtonMostrar = (Button)findViewById(R.id.button_modificacion);

          mButtonEnviar.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
       // Metodo para regresar
                 //String message = mEditSaludo.getText().toString();
                 String message2 = mEditSaludo.getText().toString();
                 Intent a = MainActivity.newIntent(OtherActivity.this,message2);
                 startActivityForResult(a,0);
             }});
        mButtonMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message=getIntent().getStringExtra(SEND_MESSAGE);
                mEditSaludo.setText("Hola " + message);

                //Asignar  nombre a mTextView
                mEditSaludo.setText("Hola " + message);


            }
        });

    }
}
