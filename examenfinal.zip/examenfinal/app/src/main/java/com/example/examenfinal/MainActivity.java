package com.example.examenfinal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button mButtonEnviar;
    private Button mButtonAnterior;
    private Button mButtonSiguiente;
    private TextView mTextView;

    private int mCurrentIndex=0;
    private final static String TAG = "etiqueta";
    private final static String KEY_INDEX = "index";
    private static final String SEND_MESSAGE = "mensaje";

    public static Intent newIntent
            (Context packageContext, String message2) {
        Intent a = new Intent(packageContext,
                MainActivity.class);
        a.putExtra(SEND_MESSAGE, message2);
        return a;
    }

    private trabajador []mTrabajador = new trabajador[]{
            new trabajador(01,"Fatima Ruiz "),
            new trabajador(02,"Teresa Wu")
    };
    private void updateStudent() {
        mTextView.setText(
                mTrabajador[mCurrentIndex].getmName()
        );
    }
    protected void onActivityResult (int requestCode, int resultCode,
                                     Intent data){
        if (resultCode != Activity.RESULT_OK){
            return;
        }
        if (requestCode==0){
            if (data==null){
                return;
            }

            String mName=OtherActivity.wasNameShown(data);
            mTextView.setText(mName);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = (TextView) findViewById(R.id.editTextsaludo);
        mButtonEnviar = (Button)findViewById(R.id.button_mostrar);
        mButtonAnterior = (Button)findViewById(R.id.button_llamar);
        mButtonSiguiente = (Button)findViewById(R.id.button_modificacion);
        updateStudent();

        mButtonSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCurrentIndex == mTrabajador.length -1)
                {
                    mCurrentIndex = 0;
                }
                else
                {
                    mCurrentIndex =mCurrentIndex+1;
                }
                updateStudent();
            }
        });

        mButtonAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCurrentIndex == 0)
                {
                    mCurrentIndex =mTrabajador.length-1;

                }
                else
                {
                    mCurrentIndex =mCurrentIndex-1;
                }
                updateStudent();

            }
        });
        mButtonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = mTrabajador[mCurrentIndex].getmName().toString();
                Intent a = OtherActivity.newIntent(MainActivity.this,message);
                startActivityForResult(a,0);

            }
        });
        if (mTextView !=null){

        }
        if (mTextView == mTextView) {
            String message=getIntent().getStringExtra(SEND_MESSAGE);
            mTextView.setText(message);
        }
    }
}
