package com.example.examenfinal;

public class trabajador {
    private int mid;
    private String mName;

    public trabajador(int mid, String mName) {
        this.mid = mid;
        this.mName = mName;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    }


